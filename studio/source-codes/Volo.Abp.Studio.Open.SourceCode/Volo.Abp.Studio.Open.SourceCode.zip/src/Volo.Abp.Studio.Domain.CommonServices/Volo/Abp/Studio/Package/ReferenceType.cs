﻿namespace Volo.Abp.Studio.Package;

public enum ReferenceType
{
    Project = 1,
    Package = 2
}
