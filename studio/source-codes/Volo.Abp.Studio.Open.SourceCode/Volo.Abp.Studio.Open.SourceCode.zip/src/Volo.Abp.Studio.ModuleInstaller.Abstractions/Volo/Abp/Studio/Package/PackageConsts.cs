﻿namespace Volo.Abp.Studio.Packages;

public static class PackageConsts
{
    public const string FileExtension = ".abppkg.json";

    public const string RoleProperty = "role";
}
