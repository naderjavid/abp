﻿namespace Volo.Abp.Studio.ModuleInstalling.Options;

public enum ModuleInstallingOptionType
{
    NotSpecified,
    Checkbox,
    FreeText,
    ComboBox
}
