﻿using System.Collections.Generic;

namespace Volo.Abp.Studio.Analyzing.Models;

public class PackageContentList : List<PackageContentItemModel>
{

}
