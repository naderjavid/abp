﻿using Volo.Abp.Modularity;

namespace Volo.Abp.Studio.Analyzing;

public class AbpStudioAnalyzingAbstractionsModule : AbpModule
{

}
